---
title: Study
layout: simple
order: 2
---
>*"What is the use of a book", thought Alice, "without pictures or conversations?"*
>
><p align="right">-- Lewis Carroll “Alice in Wonderland"</p>


### [Surviving the mathematics major at Imperial College London](/study/Imperial_mathematics/Imperial_mathematics)


  


