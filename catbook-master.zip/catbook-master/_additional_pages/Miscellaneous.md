---
title: Miscellaneous
layout: simple
order: 7
---