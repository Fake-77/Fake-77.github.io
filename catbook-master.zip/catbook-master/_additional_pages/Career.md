---
title: Career
layout: simple
order: 3
---

> *Jim Hacker: I can't believe it, Humphrey. You had a conventional strict academic upbringing. Are you denying the value of it?*
> 
> *Humphrey Appleby: Well, what's the use of it? I can't even call upon it in conversation with the Prime Minister of Great Britain.*
> 
> *Jim Hacker: Education in this country is a disaster. We're supposed to be preparing children for a working life. Three quarters of the time they're bored stiff.*
> 
> *Humphrey Appleby: Well I should have thought that being bored stiff for three quarters of the time was an excellent preparation for working life.*
> 
> *Jim Hacker: The school leaving age was raised to 16, so that they could learn more, and they're learning less.*
> 
> *Humphrey Appleby: We didn't raise it to enable them to learn more. We raised it to keep teenagers off the job market and hold down the unemployment figures.*
>  
><p align="right">-- Yes, Prime Minister, S2. E7</p>
>
>
> *吉姆·哈克： 汉弗莱，我简直难以置信。你是受传统严格的书院式的学术教育长大的，但你现在是在否认它的价值吗？*
> 
> *汉弗莱·阿普比： 那又有什么用呢？我和英国的首相说话甚至从来没用过在学校里学的那些知识。*
> 
> *吉姆·哈克：这个国家的教育就是一场灾难。我们应该教会孩子如何谋生，结果却是他们四分之三的时间都在无所事事。*
> 
> *汉弗莱·阿普比：嗯？我倒认为四分之三时间的无所事事是他们为将来如何工作谋生做的非常适合的准备。*
> 
> *吉姆·哈克：毕业年龄现在被提高到了16岁，原本是希望他们花时间学的更多，结果他们学的反而更少了。*
> 
> *汉弗莱·阿普比：我们提高毕业年龄又不是为了让他们学到更多，我们是为了把青少年拦在就业市场外，这样失业率就降低了。*
> 
><p align="right">--《是，首相》 第二季，第七集</p>