---
title: Literature
layout: simple
order: 5
---

### Some stories that I like

#### A Hunger Artist by Franz Kafka

- [English](/literature/stories/Franz_Kafka/A_Hunger_Artist)
- [Chinese](/literature/stories/Franz_Kafka/饥饿艺术家)
- [Original German](/literature/stories/Franz_Kafka/Ein_Hungerkuenstler)