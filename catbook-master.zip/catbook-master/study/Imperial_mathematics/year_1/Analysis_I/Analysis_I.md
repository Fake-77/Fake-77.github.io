---
layout: simple
title: Analysis I
---

### Contents

- [Memory Sheet](/study/Imperial_mathematics/year_1/Analysis_I/A_Sheet)

- Autumn Term Notes written by me, not completed yet ([pdf](/study/Imperial_mathematics/year_1/Analysis_I/Analysis_I.pdf), [tex](https://github.com/EinHungerkuenstler/Analysis_I_Notes_Not_Completed))

- Coursework I ([pdf](/study/Imperial_mathematics/year_1/Analysis_I/Coursework/Analysis_I_Coursework_1.pdf), [tex](https://github.com/EinHungerkuenstler/MATH40002-Analysis-I-2022-2023-Coursework-I))

- Coursework II ([pdf](/study/Imperial_mathematics/year_1/Analysis_I/Coursework/Analysis_1_Coursework_2.pdf), [tex](https://github.com/EinHungerkuenstler/MATH40002-Analysis-I-2022-2023-Cousework-II))

- Coursework III ([pdf](/study/Imperial_mathematics/year_1/Analysis_I/Coursework/Analysis_I_Coursework_3.pdf), [tex](https://github.com/EinHungerkuenstler/MATH40002-Analysis-I-2022-2023-Cousework-III))


  