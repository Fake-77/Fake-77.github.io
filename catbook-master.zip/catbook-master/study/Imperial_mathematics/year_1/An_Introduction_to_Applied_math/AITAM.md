---
layout: simple
title: An Introduction to Applied Mathematics
---
### Contents

  - [Memory Sheet](/study/Imperial_mathematics/year_1/An_Introduction_to_Applied_math/IAM_Sheet)
  
  -  Coursework I ([pdf](/study/Imperial_mathematics/year_1/An_Introduction_to_Applied_math/cousework/IAM_Coursework1.pdf), [tex](https://github.com/EinHungerkuenstler/MATH40007-An-Introduction-to-Applied-Mathematics-2022-2023-Coursework-I))
  
  -  Coursework II ([pdf](/study/Imperial_mathematics/year_1/An_Introduction_to_Applied_math/cousework/IAM_Coursework2.pdf), [tex](https://github.com/EinHungerkuenstler/MATH40007-An-Introduction-to-Applied-Mathematics-2022-2023-Coursework-II))